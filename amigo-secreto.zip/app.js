let listaAmigos = ['Laura', 'Charlie', 'Bianca', 'Francis', 'Thomas', 'Lucia', 'Kiara', 'Alex', 'Edward', 'Jhoana'];

function mostrarAmigos() {
    const ul = document.getElementById('listaAmigos');
    ul.innerHTML = '';
    listaAmigos.forEach(amigo => {
        let li = document.createElement('li');
        li.textContent = amigo;
        ul.appendChild(li);
    });
}

function agregarAmigo() {
    const input = document.getElementById('amigo');
    const nombre = input.value.trim();
    if (nombre !== '') {
        listaAmigos.push(nombre);
        input.value = '';
        mostrarAmigos();
    } else {
        alert('Por favor escribe un nombre válido');
    }
}

function sortearAmigo() {
    if (listaAmigos.length < 2) {
        alert('Agrega al menos 2 amigos para sortear.');
        return;
    }

    let copia = [...listaAmigos];
    let resultado = [];

    listaAmigos.forEach((nombre) => {
        let posibles = copia.filter(amigo => amigo !== nombre);
        if (posibles.length === 0) {
            alert("No se pudo hacer el sorteo. Intenta nuevamente.");
            return;
        }

        let sorteado = posibles[Math.floor(Math.random() * posibles.length)];
        resultado.push(`${nombre} → ${sorteado}`);
        copia.splice(copia.indexOf(sorteado), 1);
    });

    const ulResultado = document.getElementById('resultado');
    ulResultado.innerHTML = '';
    resultado.forEach(par => {
        let li = document.createElement('li');
        li.textContent = par;
        ulResultado.appendChild(li);
    });
}

document.addEventListener('DOMContentLoaded', mostrarAmigos);
